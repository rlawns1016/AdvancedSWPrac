#include "my_solver.h"
#include <time.h>
#include <math.h>
#include <stdlib.h>


// HOMEWORK

double *PDF_X, *PDF_Y, *RAN_X;
const double DELTA2 = 0.000000000001;
const int Nmax2 = 100;
const double EPSILON2 = 0.00000000001;
#define DBL_MAX2 1000000.0;
double *x2, *y2, nor_h2;
double *CDF2;
int p_num2;

void Make_CDF2()
{
	double result;
	for(int j=0; j<p_num2; j++)
	{
		CDF2[j] = 0;
		result = 0;
		for(int i=1; i <= j; i++)
		{
			result += (y2[i] + y2[i-1]) * (x2[i] - x2[i-1]) / 2.0;
		}
		CDF2[j] = result;
		result = 0;
	}
}
double _F2(double x_in)
{
	if(x_in == 0)	return 0;
	double tan;
	int num = 0;
	for(int i=0; i < p_num2 ; i++)
	{
		if(x2[i] <= x_in)
		{
			num = i;
		}
	}
	if(num == 0)	num++;
	num--;
	tan = (x_in - x2[num]) / (x2[num + 1] - x2[num]);
	return (1 - tan) * CDF2[num] + tan * CDF2[num+1];//�����ٻ�� ����
}


void program2_3()
{
	FILE *fp_r1, *fp_r2, *fp_w;
	int PDF_num, RAN_num, i, j, cnt = 0, total = 0;
	double PDF_h;

	fp_r1 = fopen("pdf_table.txt", "r");
	fp_r2 = fopen("random_event_table.txt", "r");
	fp_w = fopen("histogram.txt", "w");

	if(fp_r1 == NULL || fp_r2 == NULL || fp_w == NULL) {
		printf("input file not found....\n");
		exit(0);
	}
	fscanf(fp_r1,"%d %lf", &PDF_num, &PDF_h);
	fscanf(fp_r2,"%d",&RAN_num);
	PDF_X = (double*)malloc(sizeof(double)*PDF_num);
	PDF_Y = (double*)malloc(sizeof(double)*PDF_num);
	RAN_X = (double*)malloc(sizeof(double)*RAN_num);
	for(i=0; i<PDF_num; i++)
	{
		fscanf(fp_r1,"%lf %lf", &PDF_X[i], &PDF_Y[i]);
	}
	for(i=0; i<RAN_num; i++)
	{
		fscanf(fp_r2,"%lf", &RAN_X[i]);
	}
	for(i=0; i<PDF_num-1; i++)
	{
		for(j=0; j<RAN_num; j++)
		{
			if(RAN_X[j] >= PDF_X[i] && RAN_X[j] <= PDF_X[i+1])
				cnt++;
		}
		total += cnt;
		fprintf(fp_w,"x in [%lf , %lf] : %d\n",PDF_X[i],PDF_X[i+1],cnt);
		cnt = 0;
	}
	//fprintf(fp_w,"Total number of x2 : %d\n",total);

	if(fp_r1 != NULL) fclose(fp_r1);
	if(fp_r2 != NULL) fclose(fp_r1);
	if(fp_w != NULL) fclose(fp_w);
}

// HOMEWORK
void program2_2_a()
{
	//bisection
	__int64 start, freq, end;
	float resultTime = 0;
	FILE *fp_r, *fp_w;	
	int n_r,n_bi;
	double U;
	double a0, b0, x1;

	

	srand(time(NULL));
	fp_r = fopen("pdf_table.txt", "r");
	fp_w = fopen("random_event_table_a.txt", "w");
	fscanf(fp_r,"%d %lf", &p_num2, &nor_h2);
	printf("Input of Program2_2_a : ");
	scanf("%d", &n_r);
	fprintf(fp_w,"%d\n",n_r);
	x2=(double*)malloc(sizeof(double)*p_num2);
	y2=(double*)malloc(sizeof(double)*p_num2);
	CDF2=(double*)malloc(sizeof(double)*p_num2);
	for(int i=0; i < p_num2; i++)
	{
		fscanf(fp_r,"%lf %lf", &x2[i],&y2[i]);
	}
	CHECK_TIME_START;
	Make_CDF2();

	while (n_r--) 
	{
		U = (double)rand() / RAND_MAX; // [0, 1] ���̿� �����ϴ� ������ �� U
		n_bi = 0;
		a0 = 0;
		b0 = 1;
		x1 = (a0 + b0)/2.0;
		for(n_bi=0; ;n_bi++)
		{
			if((fabs(_F2(x1) - U) < EPSILON2) || (b0 - a0 <= DELTA2) || n_bi >= Nmax2)
			{
				break;
			}
			if(((_F2(a0) - U ) * (_F2(x1) - U)) < 0)
			{
				b0 = x1;
				x1 = (a0 + b0)/2.0;
			}
			else
			{
				a0 = x1;
				x1 = (a0 + b0)/2.0;
			}
		}
		//printf("%.15lf\n",x1);
		fprintf(fp_w,"%.15lf\n",x1);
	}
	if(fp_r != NULL) fclose(fp_r);
	if(fp_w != NULL) fclose(fp_w);
	free(x2);
	free(y2);
	free(CDF2);
	CHECK_TIME_END(resultTime);

	printf("The program2_2_a run time is %f(ms)..\n", resultTime*1000.0);
}

void program2_2_b()
{
	//secant
	__int64 start, freq, end;
	float resultTime = 0;
	FILE *fp_r, *fp_w;	
	int n_r,n_sec,n_bi;
	double U;
	double x1, x0, temp,a0,b0;

	

	srand(time(NULL));
	fp_r = fopen("pdf_table.txt", "r");
	fp_w = fopen("random_event_table_b.txt", "w");
	fscanf(fp_r,"%d %lf", &p_num2, &nor_h2);
	printf("Input of Program2_2_b : ");
	scanf("%d", &n_r);
	fprintf(fp_w,"%d\n",n_r);
	x2=(double*)malloc(sizeof(double)*p_num2);
	y2=(double*)malloc(sizeof(double)*p_num2);
	CDF2=(double*)malloc(sizeof(double)*p_num2);
	for(int i=0; i < p_num2; i++)
	{
		fscanf(fp_r,"%lf %lf", &x2[i],&y2[i]);
	}
	CHECK_TIME_START;
	Make_CDF2();

	while (n_r--) 
	{
		U = (double)rand() / RAND_MAX; // [0, 1] ���̿� �����ϴ� ������ �� U
		n_sec = 0;
		n_bi = 0;
		x0 = 0;
		a0 = 0;
		b0 = 1;
		//Using Bisection 3 times
		//For Initiating x0, x1
		x1 = (a0 + b0)/2.0;
		for(n_bi=0; ;n_bi++)
		{
			if((fabs(_F2(x1) - U) < EPSILON2) || (b0 - a0 <= DELTA2) || n_bi >= 3)
			{
				break;
			}
			if(((_F2(a0) - U ) * (_F2(x1) - U)) < 0)
			{
				b0 = x1;
				x0 = x1;
				x1 = (a0 + b0)/2.0;
			}
			else
			{
				a0 = x1;
				x0 = x1;
				x1 = (a0 + b0)/2.0;
			}
		}

		for(n_sec=0; ;n_sec++)
		{
			if((fabs(_F2(x1) - U) < EPSILON2) || (fabs(x1 - x0) <= DELTA2) || n_sec >= Nmax2)
			{
				break;
			}
			else
			{
				temp = x0;
				x0 = x1;
				x1 = x0 - ((_F2(x0) - U)*((x0 - temp)/((_F2(x0) - U) - (_F2(temp) - U))));
			}

		}
		//printf("U = %.15lf => x1 = ", U);
		//printf("%.15lf\n",x1);
		fprintf(fp_w,"%.15lf\n",x1);
	}
	if(fp_r != NULL) fclose(fp_r);
	if(fp_w != NULL) fclose(fp_w);
	free(x2);
	free(y2);
	free(CDF2);
	
	CHECK_TIME_END(resultTime);

	printf("The program2_2_b run time is %f(ms)..\n", resultTime*1000.0);
}