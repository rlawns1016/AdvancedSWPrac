#include "my_solver.h"

void main()
{
	program2_1();
	program2_2();

	// HOMEWORK
	program2_3();
}