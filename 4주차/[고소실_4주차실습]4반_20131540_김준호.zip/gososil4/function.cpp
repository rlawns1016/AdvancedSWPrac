#include "my_solver.h"
#define M_PI 3.141592

//�ǽ���
double _F1(double x) {
	return x*x - 4*x + 4 - log(x);
}

double _FP1(double x) {
	return 2*x - 4 - (1/x);
}

double _F2(double x) {
	return x + 1 - 2*sin(M_PI*x);
}

double _FP2(double x) {
	return 1 - 2*M_PI*cos(M_PI*x);
}

double _F3(double x) {
	return x*x*x*x - 11.0*x*x*x + 42.35*x*x -66.55*x +35.1384;
}

double _FP3(double x) {
	return 4*x*x*x - 33.0*x*x + 84.70*x -66.55;
}

double _F4(double x) {
	return x*x -2;
}

double _FP4(double x) {
	return 2*x;
}
//������
double _F5(double x) {
	double A;
	double B;
	double C;
	double E;
	double l = 89.0;
	double h = 49.0;
	double D = 55.0;	
	double beta=11.5/180.0;
	double x_radian=x/180;

	A = l * sin(M_PI*beta);
	B = l * cos(M_PI*beta);
	C = (h + 0.5*D)*sin(M_PI*beta) - 0.5*D*tan(M_PI*beta);
	E = (h + 0.5*D)*cos(M_PI*beta) - 0.5*D;

	return A*sin(M_PI*x_radian)*cos(M_PI*x_radian) + B*sin(M_PI*x_radian)*sin(M_PI*x_radian) - C*cos(M_PI*x_radian) -E*sin(M_PI*x_radian);
}

double _FP5(double x) {
	double A;
	double B;
	double C;
	double E;
	double l = 89.0;
	double h = 49.0;
	double D = 55.0;
	double beta=11.5/180.0;
	double x_radian=x/180;

	A = l * sin(M_PI*beta);
	B = l * cos(M_PI*beta);
	C = (h + 0.5*D)*sin(M_PI*beta) - 0.5*D*tan(M_PI*beta);
	E = (h + 0.5*D)*cos(M_PI*beta) - 0.5*D;

	return A*M_PI*cos(M_PI*x_radian)*cos(M_PI*x_radian)/180 - A*M_PI*sin(M_PI*x_radian)*sin(M_PI*x_radian)/180 + 2*B*M_PI*cos(M_PI*x_radian)*sin(M_PI*x_radian)/180 + C*M_PI*sin(M_PI*x_radian)/180 - E*M_PI*cos(M_PI*x_radian)/180;
}
