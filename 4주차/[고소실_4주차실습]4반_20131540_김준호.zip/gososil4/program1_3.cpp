#include "my_solver.h"

extern double (*_F)(double);
extern double (*_FP)(double);

/*********************************************
  Bisection Method -- HOMEWORK
**********************************************/
void program1_3(FILE *fp)
{
	double x0 = DBL_MAX;
	double a0, b0, x1, temp;
	int n;

	fprintf(fp, " n              xn1                  |f(xn1)|\n");
	scanf("%lf %lf", &a0, &b0);
	//printf("==========%lf %lf===========\n",a0,b0);
	x1 = (a0 + b0)/2.0;
	for(n=0; ;n++){
		fprintf(fp, "%2d  %20.18e  %12.10e\n", n, x1, fabs(_F(x1)));
		if((fabs(_F(x1)) < DELTA) || (fabs(x1 - x0) < EPSILON) || ( n >= Nmax)){
			break;
		}
		//printf("==%d\n",x1);
		if((_F(a0)*_F(x1)) < 0){
			b0 = x1;
			x0 = x1;
			x1 = (a0 + b0)/2.0;
		}
		else if((_F(a0)*_F(x1)) > 0) {
			a0 = x1;
			x0 = x1;
			x1 = (a0 + b0)/2.0;
		}
		else
			break;
	}
	printf("%2d  %20.18e  %12.10e\n", n, x1, fabs(_F(x1)));
}