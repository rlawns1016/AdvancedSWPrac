#include "my_solver.h"
#include <math.h>

void program3_4(void)
{
	FILE *fp_r;
	FILE *fp_w;
	int n, i, j, ia, *l;
	float *a, *a_t, *b, *b_t, *x, *s, *Ax;
	float error = 0;	//����
	float numer = 0;	//����
	float denom = 0;	//�и�
	
	fp_r = fopen("linear_system.txt", "r");
	fp_w = fopen("linear_system_solution.txt", "w");
	if (fp_r == NULL || fp_w == NULL)
	{
		printf("File Open Error\n");
		return;
	}
	printf("=======Program 3_4 START=======\n");

	fscanf(fp_r, "%d", &n);
	if (n < 1 || n > 32)
	{
		printf("Wrong Input\n");
		fclose(fp_r);
		fclose(fp_w);
		return;
	}

	a = (float *)malloc(n*n * sizeof(float));
	a_t = (float *)malloc(n*n * sizeof(float));
	b = (float *)malloc(n * sizeof(float));
	b_t = (float *)malloc(n * sizeof(float));
	x = (float *)malloc(n * sizeof(float));
	s = (float *)malloc(n * sizeof(float));
	l = (int *)malloc(n * sizeof(int));
	Ax = (float *)malloc(n * sizeof(float));

	ia = n;

	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++) 
		{
			fscanf(fp_r, "%f", &a[j*n + i]);	//Row major
			a_t[j*n + i] = a[j*n + i];
		}
	}

	for (i = 0; i < n; i++) 
	{
		fscanf(fp_r, "%f", &b[i]);
		b_t[i] = b[i];
	}

	gespp_(&n, a, &ia, l, s);
	solve_(&n, a, &ia, l, b, x);

	fprintf(fp_w, "n = %d\n", n);
	for (i = 0; i < n; i++)
	{
		fprintf(fp_w, "X%d = %.6f\n",i, x[i]);
	}

	for (i = 0; i < n; i++)
	{
		denom += b_t[i] * b_t[i];
	}
	denom = sqrt(denom);

	for (i = 0; i < n; i++)
	{
		Ax[i] = 0;
		for (j = 0; j < n; j++)
		{
			Ax[i] += a_t[j*n + i] * x[j];
		}
	}

	for (i = 0; i < n; i++)
	{
		numer += (Ax[i] - b_t[i]) * (Ax[i] - b_t[i]);
	}
	numer = sqrt(numer);

	error = numer / denom;

	fprintf(fp_w, "Error = %.6f\n", error);

	printf("linear_system_solution.txt is created\n");
	fclose(fp_r);
	fclose(fp_w);
	printf("========Program 3_4 END========\n\n");
}