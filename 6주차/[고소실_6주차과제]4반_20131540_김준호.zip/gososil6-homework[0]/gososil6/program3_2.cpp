#include "my_solver.h"
#include <math.h>

#define SOLNUMS 4
#define MATCOLS SOLNUMS
#define MATROWS SOLNUMS
#define TOLERANCE 0.0000001

void fcn3_2(int *n, double *x, double *fvec, int *iflag)
{
	fvec[0] = x[0] + x[1] + 9;
	fvec[1] = sqrt(5.0) * (x[2] - x[3]) - 2 * sqrt(5.0);
	fvec[2] = pow((x[1] - 2 * x[3]), 2) - 9;
	fvec[3] = sqrt(10.0) * pow((x[0] - x[3]), 2) - 2 * sqrt(10.0);
}

void program3_2(void)
{
	FILE *fp_w;
	int n = SOLNUMS;
	double x[SOLNUMS];	//x[0] : x, x[1] : y, x[2] : z, x[3] : w
	double fvec[SOLNUMS];
	double tol = TOLERANCE;
	int info;
	double wa[(SOLNUMS * (3 * SOLNUMS + 13)) / 2];
	int lwa = (SOLNUMS * (3 * SOLNUMS + 13)) / 2;
	
	fp_w = fopen("roots_found3-2.txt", "w");
	if (fp_w == NULL)
	{
		printf("File Open Error\n");
		return;
	}
	printf("=======Program 3_2 START=======\n");
	x[0] = 0.9;	x[1] = -0.9; x[2] = 1.25; x[3] = -1.25;

	hybrd1_(fcn3_2, &n, x, fvec, &tol, &info, wa, &lwa);

	switch (info)
	{
	case 0:
		fprintf(fp_w, "Info = 0 :\nImproper input parameters.\n");
		break;
	case 1:
		fprintf(fp_w, "Info = 1 :\nAlgorithm estimates that the relative error between x and the solution is at most tol.\n");
		break;
	case 2:
		fprintf(fp_w, "Info = 2 :\nNumber of calls to fcn with iflag = 1 has reached 100*(n+1).\n");
		break;
	case 3:
		fprintf(fp_w, "Info = 3 :\ntol is too small. No further improvement in the approximate solution x is possible.\n");
		break;
	case 4:
		fprintf(fp_w, "Info = 4 :\nIteration is not making good progress.\n");
		break;
	}

	fprintf(fp_w, "\n(x, y, z, w) : (%lf %lf %lf %lf)\n\n", x[0], x[1], x[2], x[3]);
	fprintf(fp_w, "x + 10y - 9 = %lf\n", fvec[0]);
	fprintf(fp_w, "5(z - w) - 2��5 = %lf\n", fvec[1]);
	fprintf(fp_w, "(y - 2z)^2 - 9 = %lf\n", fvec[2]);
	fprintf(fp_w, "��10(x - w)^2 - 2��10 = %lf\n", fvec[3]);

	printf("roots_found3-2.txt is created\n");
	fclose(fp_w);
	printf("========Program 3_2 END========\n\n");
	//getchar();
}