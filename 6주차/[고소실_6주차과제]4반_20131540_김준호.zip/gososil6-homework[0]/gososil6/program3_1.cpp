#include "my_solver.h"
#include <math.h>

#define SOLNUMS 4
#define MATCOLS SOLNUMS
#define MATROWS SOLNUMS
#define TOLERANCE 0.0000001

double input_I[5][5];
double input_II[5][5];

void fcn3_1_i(int *n, double *x, double *fvec, double *fjac, int *ldfjac, int *iflag)
{
	// origin function F(x)
	if (*iflag == 1) {
		fvec[0] = pow(x[0] - input_I[1][0], 2) + pow(x[1] - input_I[1][1], 2) + pow(x[2] - input_I[1][2], 2) - pow((input_I[0][0] * (input_I[1][4] + x[3] - input_I[1][3])), 2);
		fvec[1] = pow(x[0] - input_I[2][0], 2) + pow(x[1] - input_I[2][1], 2) + pow(x[2] - input_I[2][2], 2) - pow((input_I[0][0] * (input_I[2][4] + x[3] - input_I[2][3])), 2);
		fvec[2] = pow(x[0] - input_I[3][0], 2) + pow(x[1] - input_I[3][1], 2) + pow(x[2] - input_I[3][2], 2) - pow((input_I[0][0] * (input_I[3][4] + x[3] - input_I[3][3])), 2);
		fvec[3] = pow(x[0] - input_I[4][0], 2) + pow(x[1] - input_I[4][1], 2) + pow(x[2] - input_I[4][2], 2) - pow((input_I[0][0] * (input_I[4][4] + x[3] - input_I[4][3])), 2);
	}
	// Jacobi matrix J(x)
	else if (*iflag == 2) {
		fjac[0] = 2 * (x[0] - input_I[1][0]);  fjac[4] = 2 * (x[1] - input_I[1][1]);  fjac[8] = 2 * (x[2] - input_I[1][2]); fjac[12] = (-2) * input_I[0][0] * input_I[0][0] * (input_I[1][4] + x[3] - input_I[1][3]);
		fjac[1] = 2 * (x[0] - input_I[2][0]);  fjac[5] = 2 * (x[1] - input_I[2][1]);  fjac[9] = 2 * (x[2] - input_I[2][2]); fjac[13] = (-2) * input_I[0][0] * input_I[0][0] * (input_I[2][4] + x[3] - input_I[2][3]);
		fjac[2] = 2 * (x[0] - input_I[3][0]);  fjac[6] = 2 * (x[1] - input_I[3][1]);  fjac[10] = 2 * (x[2] - input_I[3][2]); fjac[14] = (-2) * input_I[0][0] * input_I[0][0] * (input_I[3][4] + x[3] - input_I[3][3]);
		fjac[3] = 2 * (x[0] - input_I[4][0]);  fjac[7] = 2 * (x[1] - input_I[4][1]);  fjac[11] = 2 * (x[2] - input_I[4][2]); fjac[15] = (-2) * input_I[0][0] * input_I[0][0] * (input_I[4][4] + x[3] - input_I[4][3]);
	}
}

void fcn3_1_ii(int *n, double *x, double *fvec, int *iflag)
{
	fvec[0] = pow(x[0] - input_II[1][0], 2) + pow(x[1] - input_II[1][1], 2) + pow(x[2] - input_II[1][2], 2) - pow((input_II[0][0] * (input_II[1][4] + x[3] - input_II[1][3])), 2);
	fvec[1] = pow(x[0] - input_II[2][0], 2) + pow(x[1] - input_II[2][1], 2) + pow(x[2] - input_II[2][2], 2) - pow((input_II[0][0] * (input_II[2][4] + x[3] - input_II[2][3])), 2);
	fvec[2] = pow(x[0] - input_II[3][0], 2) + pow(x[1] - input_II[3][1], 2) + pow(x[2] - input_II[3][2], 2) - pow((input_II[0][0] * (input_II[3][4] + x[3] - input_II[3][3])), 2);
	fvec[3] = pow(x[0] - input_II[4][0], 2) + pow(x[1] - input_II[4][1], 2) + pow(x[2] - input_II[4][2], 2) - pow((input_II[0][0] * (input_II[4][4] + x[3] - input_II[4][3])), 2);
}

void program3_1_i(void)
{
	FILE *fp_r;
	FILE *fp_w;
	int n = SOLNUMS;
	double x[SOLNUMS] = { 1.0, 2.0, 3.0, 4.0 };
	double fvec[SOLNUMS];
	double fjac[MATCOLS * MATROWS];
	int ldfjac = SOLNUMS;
	double tol = TOLERANCE;
	int info;
	double wa[(SOLNUMS * (SOLNUMS + 13)) / 2];
	int lwa = (SOLNUMS * (SOLNUMS + 13)) / 2;
	int i, j, testnum;
	char input_filename[17] = { 'G','P','S','_','s','i','g','n','a','l','_','0','.','t','x','t' };
	char output_filename[23] = { 'G','P','S','_','p','o','s','i','t','i','o','n','_','3','-','1','_','0','.','t','x','t' };

	for (testnum = 0; testnum < 3; testnum++)
	{
		input_filename[11] = (char)(testnum + '0');
		output_filename[17] = (char)(testnum + '0');
		fp_r = fopen(input_filename, "r");
		fp_w = fopen(output_filename, "w");
		if (fp_r == NULL || fp_w == NULL)
		{
			printf("File Open Error\n");
			return;
		}
		
		fscanf(fp_r, "%lf%lf", &input_I[0][0], &input_I[0][1]);
		input_I[0][2] = input_I[0][3] = 0;
		for (i = 1; i <= 4; i++)
		{
			for (j = 0; j < 5; j++)
			{
				fscanf(fp_r, "%lf", &input_I[i][j]);
			}
		}

		printf("<=HYBRJ1=>  Test #%d\nInitialize x1 x2 x3 x4 : ", testnum);

		for (i = 0; i < 4; i++)
		{
			scanf("%lf", &x[i]);
		}
		getchar();

		hybrj1_(fcn3_1_i, &n, x, fvec, fjac, &ldfjac, &tol, &info, wa, &lwa);
		switch (info)
		{
		case 0:
			fprintf(fp_w,"Info = 0 :\nImproper input parameters.\n");
			break;
		case 1:
			fprintf(fp_w, "Info = 1 :\nAlgorithm estimates that the relative error between x and the solution is at most tol.\n");
			break;
		case 2:
			fprintf(fp_w, "Info = 2 :\nNumber of calls to fcn with iflag = 1 has reached 100*(n+1).\n");
			break;
		case 3:
			fprintf(fp_w, "Info = 3 :\ntol is too small. No further improvement in the approximate solution x is possible.\n");
			break;
		case 4:
			fprintf(fp_w, "Info = 4 :\nIteration is not making good progress.\n");
			break;
		}
		fprintf(fp_w, "\nX : %lf %lf %lf %lf\n\n", x[0], x[1], x[2], x[3]);
		for (i = 0; i < 4; i++) {
			fprintf(fp_w, "F%d(%lf,%lf,%lf,%lf) = %lf\n", i, x[0], x[1], x[2], x[3], fvec[i]);
		}

		fclose(fp_r);
		fclose(fp_w);
		printf("%s is created\n\n",output_filename);
	}
}
void program3_1_ii(void)
{
	FILE *fp_r;
	FILE *fp_w;
	int n = SOLNUMS;
	double x[SOLNUMS];
	double fvec[SOLNUMS];
	double tol = TOLERANCE;
	int info;
	double wa[(SOLNUMS * (3 * SOLNUMS + 13)) / 2];
	int lwa = (SOLNUMS * (3 * SOLNUMS + 13)) / 2;
	int i, j, testnum;
	char input_filename[17] = { 'G','P','S','_','s','i','g','n','a','l','_','0','.','t','x','t' };
	char output_filename[23] = { 'G','P','S','_','p','o','s','i','t','i','o','n','_','3','-','2','_','0','.','t','x','t' };

	for (testnum = 0; testnum < 3; testnum++)
	{
		input_filename[11] = (char)(testnum + '0');
		output_filename[17] = (char)(testnum + '0');
		fp_r = fopen(input_filename, "r");
		fp_w = fopen(output_filename, "w");
		if (fp_r == NULL || fp_w == NULL)
		{
			printf("File Open Error\n");
			return;
		}

		fscanf(fp_r, "%lf%lf", &input_II[0][0], &input_II[0][1]);
		input_II[0][2] = input_II[0][3] = 0;
		for (i = 1; i <= 4; i++)
		{
			for (j = 0; j < 5; j++)
			{
				fscanf(fp_r, "%lf", &input_II[i][j]);
			}
		}

		printf("<=HYBRD1=>  Test #%d\nInitialize x1 x2 x3 x4 : ", testnum);

		for (i = 0; i < 4; i++)
		{
			scanf("%lf", &x[i]);
		}
		getchar();

		hybrd1_(fcn3_1_ii, &n, x, fvec, &tol, &info, wa, &lwa);
		switch (info)
		{
		case 0:
			fprintf(fp_w, "Info = 0 :\nImproper input parameters.\n");
			break;
		case 1:
			fprintf(fp_w, "Info = 1 :\nAlgorithm estimates that the relative error between x and the solution is at most tol.\n");
			break;
		case 2:
			fprintf(fp_w, "Info = 2 :\nNumber of calls to fcn with iflag = 1 has reached 100*(n+1).\n");
			break;
		case 3:
			fprintf(fp_w, "Info = 3 :\ntol is too small. No further improvement in the approximate solution x is possible.\n");
			break;
		case 4:
			fprintf(fp_w, "Info = 4 :\nIteration is not making good progress.\n");
			break;
		}
		fprintf(fp_w, "\nX : %lf %lf %lf %lf\n\n", x[0], x[1], x[2], x[3]);
		for (i = 0; i < 4; i++) {
			fprintf(fp_w, "F%d(%lf,%lf,%lf,%lf) = %lf\n", i, x[0], x[1], x[2], x[3], fvec[i]);
		}

		fclose(fp_r);
		fclose(fp_w);
		printf("%s is created\n\n", output_filename);
	}
}
void program3_1(void)
{
	printf("=======Program 3_1 START=======\n");
	program3_1_i();
	printf("========================\n\n");
	program3_1_ii();
	printf("========Program 3_1 END========\n\n");
}